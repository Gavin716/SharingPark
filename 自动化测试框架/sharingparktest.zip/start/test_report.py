import os

from sharingparktest.tools.util import LogUtil, TimeUtil
from sharingparktest.tools.util import DBUtil
class TestReport:

    def __init__(self, app_name):
        self.app_name = app_name
        self.logger = LogUtil.get_logger(os.path.join(os.getcwd(), 'test_report'))

    def write_result_db(self, result_info):

        now = TimeUtil.get_standard_format_time()
        sql = 'insert into %s (version, module, case_type, case_id,case_desc, case_result, execute_time, error_msg, error_screenshot) ' \
              'values ("%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s")' \
              %(self.app_name, result_info['version'], result_info['module'], result_info['case_type'],
                result_info['case_id'], result_info['case_desc'], result_info['case_result'],
                f"{now}", result_info['error_msg'], result_info['error_screenshot'], result_info['api_url'], result_info['request_mrthod'] )
        DBUtil("db_report").updata_db(sql)

    def generate_html_report(self, version):
        # 根据不同版本读取该版本的测试结果数据
        sql_all = f'select * from {self.app_name} where version = "{version}"'
        all_result = DBUtil('db_report').query_all(sql_all)
        if len(all_result) == 0:
            self.logger.info("该版本暂无测试结果")
            return
        # 计算测试执行成功的数量
        sql_success = f'select count(*) from {self.app_name} where version="{version}" and case_result="测试通过"'
        success_result = DBUtil('db_report').query_one(sql_success)[0]
        # 计算测试执行失败的数据
        sql_fail = f'select count(*) from {self.app_name} where version="{version}" and case_result="测试失败"'
        fail_result = DBUtil('db_report').query_one(sql_fail)[0]
        # 计算测试执行错误的数据
        sql_error = f'select count(*) from {self.app_name} where version="{version}" and case_result="错误"'
        error_result = DBUtil('db_report').query_one(sql_error)[0]
        # 获取最后一条用例执行的时间
        lasttime_sql = 'select execute_time from test_result order by execute_time desc limit 0,1'
        lasttime = str(DBUtil('db_report').query_one(lasttime_sql)[0])
        # 获取日期
        test_data = lasttime.split(' ')[0]
        # 替换html页面中指定位置的数据
        result_str = ''
        for result in all_result:
            if result[6] == '#6A5ACD':
                color = 'blue'
            elif result[6] == '测试失败':
                color = '#FF69B4'
            else:
                color = '#FFD700'
            if result[9] == '无':
                screenshot = '无'
            else:
                screenshot = f'<a href="{result[9]}">查看截图</a>'

            # 表格中添加内容
            result_str += f'<tr height="40">' \
                          f'<td width="3%">{result[0]}</td>' \
                          f'<td width="9%">{result[2]}</td>' \
                          f'<td width="9%">{result[3]}</td>' \
                          f'<td width="10%">{result[4]}</td>' \
                          f'<td width="16%">{result[10]}</td>' \
                          f'<td width="4%">{result[11]}</td>' \
                          f'<td width="20%">{result[5]}</td>' \
                          f'<td width="7%" bgcolor="{color}">{result[6]}</td>' \
                          f'<td width="8%">{result[7]}</td>' \
                          f'<td width="8%">{result[8]}</td>' \
                          f'<td width="6%">{screenshot}</td>' \
                          f'</tr>\r\n'

            # 替换模板上特定位置的字符串
            with open('..\\conf\\template.html', encoding='utf-8') as file:
                contents = file.read()
            contents = contents.replace('$test-date', test_data)
            contents = contents.replace('$test-version', version)
            contents = contents.replace('$pass-count', str(success_result))
            contents = contents.replace('$fail-count', str(fail_result))
            contents = contents.replace('$error-count', str(error_result))
            contents = contents.replace('$last-time', lasttime)
            contents = contents.replace('$test-result', result_str)
            # 将内容写入新的测试报告中
            if not os.path.exists(f'..\\report\\{version}'):
                os.mkdir(f'..\\report\\{version}')
            report_path = f'..\\report\\{version}\\{self.app_name}{version}版本测试报告.html'
            with open(report_path, 'w', encoding='utf-8') as file:
                file.write(contents)




if __name__ == '__main__':
    test = TestReport('test_result')
    # result_info = {
    #     "version":"v1.0", "module":"登录", "case_type":"GUI", "case_id":"login_04",
    #     "case_desc":"登录成功", "case_result":"测试通过", "error_msg":"无",
    #     "error_screenshot" :"无"
    # }
    test.generate_html_report("v1.0")

import unittest

from sharingparktest.tools.util import FileUtil
from HTMLTestRunner_cn import HTMLTestRunner

class Start:

    def start(self, path):

        # suite = unittest.TestSuite()
        # loader = unittest.TestLoader()
        test_class_info = FileUtil.get_txt_line(path)
        # print(type(test_class_info))
        # tests = loader.loadTestsFromNames(test_class_info)
        # suite.addTests(tests)
        # with open('report.html', 'w') as file:
        #     runner = HTMLTestRunner(stream=file, verbosity=2)
        #     runner.run(suite)



if __name__ == '__main__':
    start = Start()
    start.start("..\\conf\\api_case_path")
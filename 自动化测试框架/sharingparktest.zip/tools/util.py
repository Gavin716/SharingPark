import os

class TimeUtil:

    @classmethod
    def get_filename_time(cls):
        """
        返回规定格式的用于文件名的时间字符串
        :return:时间字符串格式为%Y%m%d_%H%M%S
        """
        import time
        return time.strftime('%Y%m%d_%H%M%S', time.localtime())

    @classmethod
    def get_standard_format_time(cls):
        """
        返回标准格式的时间字符串
        :return:返回的时间格式为%Y-%m-%d %H:%M:%S
        """
        import time
        return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())


class LogUtil:

    logger = None

    @classmethod
    def get_logger(cls,name):
        """
        生成日志文件
        信息级别：调试debug，普通info，警告warn，错误error
        :param name: 调用logger的模块名
        :return:日志生成器对象
        """
        import logging
        if cls.logger is None:
            # 获取日志生成器对象
            cls.logger = logging.getLogger(name)
            # 定义获取信息的级别
            cls.logger.setLevel(level=logging.INFO)
            # 如果目录不存在则创建
            if not os.path.exists("..\\logs"):
                os.mkdir("..\\logs")
            #创建logger的文件句柄与规定的文件关联
            handler = logging.FileHandler("..\\logs\\"+TimeUtil.get_filename_time()+".log",encoding="utf8")
            # 定义log信息的格式
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            handler.setFormatter(formatter)
            cls.logger.addHandler(handler)

        return cls.logger


class FileUtil:
    logger = LogUtil.get_logger(os.path.join(os.getcwd(), "util"))

    @classmethod
    def get_txt(cls,path):
        """
        读取普通文本文件内容
        :param path: 文本文件路径
        :return: 文本文件内容字符串
        """
        content = None
        try:
            with open(path,encoding="utf8") as rf:
                content = rf.read()
        except:
            cls.logger.error(f"没有读取{path}文件")
        finally:
            return content

    @classmethod
    def get_txt_line(cls, path):
        """
        按行读取文本内容，返回列表加字符串格式
        :param path: 文本路径
        :return: 列表加字符串（去掉\n,#开始的行内容）
        """
        content = []
        try:
            with open(path, encoding="utf8") as rf:
                contents = rf.readlines()
            for data in contents:
                if not data.startswith("#"):
                    temp = data.strip()
                    content.append(temp)
        except:
            cls.logger.error(f"没有读取{path}文件")
        finally:
            return content

    @classmethod
    def get_json(cls,path):
        """
            从json格式文件中读取原始格式内容并返回
        :param path:
            要读取的json文件路径
        :return:
            原始数据类型的数据
        """
        import json5
        content = None
        try:
            with open(path, "r", encoding="utf8") as rf:
                content = json5.load(rf)
            cls.logger.info("读取正确")
        except:
            cls.logger.info("文件读取失败")
        finally:
            return content


    @classmethod
    def get_test_info_ui(cls, path, section, option):
        """
        从test_info.ini读取ui测试的excel配置信息，将excel内容全部读出
        :param path:测试信息配置文件路径及文件名
        :param section: 页面名称
        :param option: 每条测试信息的键
        :return: 测试信息的json格式
        """
        params = eval(cls.get_ini_value(path, section, option))
        import xlrd
        # 读取excel文件
        workbook = xlrd.open_workbook(params["test_info_path"])
        # 取出sheet页的内容
        sheet_content = workbook.sheet_by_name(params["sheet_name"])
        case_sheet_content = workbook.sheet_by_name(params['case_sheet_name'])
        version = case_sheet_content.cell(1, 1).value
        # 读取指定列的内容
        contents = []
        for i in range(params["start_row"],params["end_row"]):
            test_data = sheet_content.cell(i,params["test_data_col"]).value
            except_result = sheet_content.cell(i,params["expect_col"]).value
            testlist = test_data.split("\n")
            tempdict = {}
            tempdict['version'] = version
            tempdict['caseid'] = sheet_content.cell(i, params['caseid_col']).value
            tempdict['module'] = sheet_content.cell(i, params['module_col']).value
            tempdict['type'] = sheet_content.cell(i, params['type_col']).value
            tempdict['desc'] = sheet_content.cell(i, params['desc_col']).value
            for j in testlist:
                templist = j.split("=")
                tempdict[templist[0]]=templist[1]
            tempdict["except"]=except_result
            # print(tempdict)
            contents.append(tempdict)
        return contents

    @classmethod
    def get_test_info_api(cls, path, section, option):
        """
        从test_info.ini读取api测试的excel配置信息，将excel内容全部读出
        :param path:测试信息配置文件路径及文件名
        :param section: 页面名称
        :param option: 每条测试信息的键
        :return: 测试信息的json格式
        """
        params = eval(cls.get_ini_value(path, section, option))
        import xlrd
        # 读取excel文件
        workbook = xlrd.open_workbook(params["test_info_path"])
        # 取出sheet页的内容
        sheet_content = workbook.sheet_by_name(params["sheet_name"])
        case_sheet_content = workbook.sheet_by_name(params['case_sheet_name'])
        version = case_sheet_content.cell(1, 1).value
        # 读取指定列的内容
        contents = []
        for i in range(params["start_row"], params["end_row"]):
            test_data = sheet_content.cell(i, params["test_data_col"]).value
            except_result = sheet_content.cell(i, params["expect_col"]).value
            testlist = test_data.split("\n")
            tempdict = {}
            request_parmas = {} #用于接收请求的参数
            tempdict['version'] = version
            tempdict['caseid'] = sheet_content.cell(i, params['caseid_col']).value
            tempdict['module'] = sheet_content.cell(i, params['module_col']).value
            tempdict['type'] = sheet_content.cell(i, params['type_col']).value
            tempdict['desc'] = sheet_content.cell(i, params['desc_col']).value
            tempdict['uri'] = sheet_content.cell(i, params['uri_col']).value
            tempdict['request_method'] = sheet_content.cell(i, params['request_method_col']).value
            for j in testlist:
                templist = j.split("=")
                request_parmas[templist[0]] = templist[1]
            tempdict["params"] = request_parmas
            tempdict["expect"] = except_result
            # print(tempdict)
            contents.append(tempdict)
        return contents

    @classmethod
    def get_ini_value(cls,path,section,option):
        """
        从ini配置文件中读取某个指定的键对应的值并返回
        :param path: 配置文件路径
        :param section: 节点名称
        :param option: 键名称
        :return: 返回对应的单值
        """
        import configparser
        cp = configparser.ConfigParser()
        value = None
        try:
            cp.read(path,encoding="utf-8-sig")
            value = cp.get(section,option)
        except:
            cls.logger.error("读取配置文件错误")
        return value

    @classmethod
    def get_ini_section(cls,path,setion):
        """
        从ini配置文件中读取某个节点下的所有内容，以字典格式返回
        :param path:
        :param section:
        :return:
        """
        import configparser
        cp = configparser.ConfigParser()
        temp_list = []
        try:
            cp.read(path,encoding="utf-8-sig")
            temp = cp.items(setion) #列表套元组，元组为（键，值）
            for i in temp:
                temp_dict = {}
                temp_dict[i[0]] = i[1]
                temp_list.append(temp_dict)
        except:
            cls.logger.error("读取配置文件错误")
        finally:
            return temp_list


class DBUtil:
    """
    该类包含数据库连接方法，查询单条数据方法，查询多条数据方法，增删改功能
    """
    logger = LogUtil.get_logger(os.path.join(os.getcwd(), "util"))

    def __init__(self, option):
        self.db_info = FileUtil.get_ini_value("..\\conf\\base.ini", "mysql", f"{option}")


    def get_conn(self):
        """
        连接数据库返回数据库连接对象
        :param db_info: 数据库配置信息
        :return: 返回数据库连接对象
        """
        import pymysql
        conn = None
        try:
            conn = pymysql.connect(host=self.db_info[0],database=self.db_info[1],user=self.db_info[2],password=self.db_info[3],charset=self.db_info[4])
        except:
            self.logger.error("数据库连接失败")
        return conn


    def query_one(self,sql):
        """
        查询单条结果
        :param sql: 查询语句
        :return: 以元组类型返回单条结果集
        """
        conn = self.get_conn()
        cur = conn.cursor()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchone()
        except:
            self.logger.error("查询失败")
        finally:
            cur.close()
            conn.close()
            return result


    def query_all(self,sql):
        """
        查询多条结果
        :param sql: 查询语句
        :return: 以二维元组返回多条结果集
        """
        conn = self.get_conn()
        cur = conn.cursor()
        result = None
        try:
            cur.execute(sql)
            result = cur.fetchall()
        except:
            self.logger.error("查询失败")
        finally:
            cur.close()
            conn.close()
            return result

    def updata_db(self,sql):
        """
        增删改操作
        :param sql:DML语句
        :return: 执行成功或者失败的标记
        """
        conn = self.get_conn()
        cur = conn.cursor()
        flag = None
        try:
            cur.execute(sql)
            conn.commit()
        except:
            flag = False
            self.logger.error("sql执行失败")
        finally:
            cur.close()
            conn.close()
            return flag




if __name__ == '__main__':
    # print(FileUtil().get_excel_data("../conf/test_info", 0))
    # print(DBUtil.query_all("select * from user"))
    # print(FileUtil.get_ini_section("..\\conf\\base.ini","host"))
    # print(FileUtil.get_ini_value("..\\conf\\base.ini","mysql","db_info"))
    print(FileUtil.get_test_info_ui("..\\conf\\test_info.ini", "login" ,"login_info"))
import os

from selenium.webdriver.common.by import By
from sharingparktest.tools.util import LogUtil, TimeUtil
from sharingparktest.tools.util import FileUtil
from pymouse import PyMouse
from pykeyboard import PyKeyboard

class APIutil:

    @classmethod
    def get_session(cls):
        """
        获取具有权限的session
        :return:带登录cookie的session
        """
        import requests
        session = requests.session()
        session.get('http://192.168.126.131:8080/SharedParkingPlace/image')
        login_url = FileUtil.get_ini_value('..\\conf\\base.ini', 'api', 'login_url')
        login_data = eval(FileUtil.get_ini_value('..\\conf\\base.ini', 'api', 'login_data'))
        res = session.get(login_url,params=login_data).text
        print(res)
        return session

    @classmethod
    def request(cls, method, url, data=None):
        """
        发送请求获得响应
        :param method: 请求方式
        :param url: 请求URl
        :param data: 请求数据
        :return: 响应结果
        """
        session = cls.get_session()
        resp = getattr(session, method)(url,params=data)
        return resp

    @classmethod
    def assert_api(cls, test_info):
        for info in test_info:
            resp = cls.request(info['request_method'], info['uri'], info['params'])
            Assert.assert_equal(info['expect'], resp.text)


class UIutil:

    driver = None
    logger = LogUtil.get_logger(os.path.join(os.getcwd()+"ui_util"))
    mouse = PyMouse()
    keyboard = PyKeyboard()

    @classmethod
    def get_driver(cls):
        from selenium import webdriver
        try:
            browser = FileUtil.get_ini_value("..\\conf\\base.ini", "ui", "browser")
            base_url = FileUtil.get_ini_value("..\\conf\\base.ini", "ui", "base_url")
            if cls.driver is None:
                cls.driver = getattr(webdriver,browser)()
                cls.driver.implicitly_wait(5)
                cls.driver.maximize_window()
                cls.driver.get(base_url)
        except:
            cls.logger.error("浏览器未正常打开，请查看配置文件")
        return cls.driver

    @classmethod
    def find_element(cls, section, option):
        """
        通过不同元素定位方式查找元素
        :param section:inspector.ini的节点
        :param option:键对应的是元素定位方式及查找的元素
        :return:
        """
        try:
            element_attr = FileUtil.get_ini_section("..\\conf\\inspector.ini", section)
            for element in element_attr:
                if option in element.keys():
                    attr = eval(element[option])
                    return cls.driver.find_element(getattr(By, attr[0]), attr[1])
        except:
            return None


    @classmethod
    def input(cls,element,value):
        """
        点击文本输入框，清理并输入新的值
        :param element: 文本元素对象
        :param value: 输入的值
        :return: 无
        """
        element.click()
        element.clear()
        element.send_keys(value)

    @classmethod
    def click(cls,element):
        """
        点击某个元素
        :param element: 元素对象
        :return: 无
        """
        element.click()

    @classmethod
    def select_rdm(cls,element):
        """
        随机选择下拉框中的某一项
        :param element: 下拉框元素对象
        :return: 无
        """
        import random
        from selenium.webdriver.support.select import Select
        random_index = random.randint(0,len(Select(element).options)-1)
        Select(element).select_by_index(random_index)

    @classmethod
    def select_by_text(cls,element,text):
        """
        根据下拉框文本选择
        :param element: 下拉框元素对象
        :param text: 可见的文本
        :return: 无
        """
        from selenium.webdriver.support.select import Select
        Select(element).select_by_visible_text(text)

    @classmethod
    def del_time_readonly(cls, element):
        """
        去除时间的只读模式变为可输入的文本框
        :param element:
        :return:
        """
        js = f'document.getElementById("{element}").removeAttribute("readonly")'
        cls.driver.execute_script(js)

    @classmethod
    def is_element_present(cls,driver,how,what):
        """
        判断某个元素是否存在
        :param driver:
        :param how:
        :param what:
        :return:
        """
        try:
            driver.find_element(by=how, value=what)
            return True
        except:
            cls.logger.error(f'没有找到方式为{how}，值为{what}的元素')
            return False


    @classmethod
    def find_image(cls,target):
        # 图片存放路径
        image_path = "..\\image"
        # 定义大图截图保存位置
        screen_path = os.path.join(image_path,"screen.png")
        from PIL import ImageGrab
        ImageGrab.grab().save(screen_path)
        # 分别获取大图和小图对象
        import cv2
        screen = cv2.imread(screen_path)
        template = cv2.imread(os.path.join(image_path,target))
        # 进行模板匹配，参数包括大小图对象和匹配算法
        result = cv2.matchTemplate(screen,template,cv2.TM_CCOEFF_NORMED)
        # 获取匹配结果
        min, max, min_loc, maxloc = cv2.minMaxLoc(result)
        similarity = FileUtil.get_ini_value("..\\conf\\base.ini", "imagematch", "similarity")
        if max < float(similarity):
            return -1, -1

        x = maxloc[0] + int(template.shape[1] / 2)
        y = maxloc[1] + int(template.shape[0] / 2)
        return x, y

    @classmethod
    def screen_shot(cls,driver,path):
        driver.get_screenshot_as_file(path)

    @classmethod
    def click_image(cls, target):
        """
        单击一张图片
        :param target:
        :return:
        """
        x, y = cls.find_image(target)
        if x == -1 and y == -1:
            cls.logger.error(f'{target}图片未匹配')
            return
        cls.mouse.click(x, y)

    @classmethod
    def double_click_image(cls, target):
        """
        双击一张图片
        :param target:
        :return:
        """
        x, y = cls.find_image(target)
        if x == -1 and y == -1:
            cls.logger.error(f'{target}图片未匹配')
            return
        cls.mouse.click(x, y, n=2)

    @classmethod
    def input_image(cls,target,msg):
        x, y = cls.find_image(target)
        if x == -1 and y == -1:
            cls.logger.error(f'{target}图片未匹配')
            return
        cls.keyboard.type_string(msg)

    @classmethod
    def select_image(cls,target,count):
        """
        匹配图片选择下拉框
        :param target:
        :param count:
        :return:
        """
        # 点击下拉框
        cls.click_image(target)
        # count次执行键盘操作
        for i in range(count):
            cls.keyboard.press_key(cls.keyboard.down_key)
        cls.keyboard.press_key(cls.keyboard.enter_key)


class Assert:

    @classmethod
    def assert_equal(cls, expect, actual):
        if expect == actual:
            test_result = '测试通过'
        else:
            test_result = '测试失败'
        print(test_result)



if __name__ == '__main__':
    # driver = UIutil.get_driver()
    # # print(UIutil.find_element("login","username"))
    # UIutil.screen_shot(driver, "..\\demo\\mage.png")
    APIutil.get_session()